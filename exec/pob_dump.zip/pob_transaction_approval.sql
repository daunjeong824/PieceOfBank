-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a703.p.ssafy.io    Database: pob
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction_approval`
--

DROP TABLE IF EXISTS `transaction_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_approval` (
  `amount` bigint NOT NULL,
  `notification_id` bigint NOT NULL,
  `transaction_approval_id` bigint NOT NULL AUTO_INCREMENT,
  `receiver_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('APPROVED','EXPIRED','PENDING','REFUSED') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`transaction_approval_id`),
  UNIQUE KEY `UKrvftbgmabvaeqhyr00x6pjk6s` (`notification_id`),
  CONSTRAINT `FK1ay8qy317fig4rc4cqf25lcu0` FOREIGN KEY (`notification_id`) REFERENCES `notification` (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_approval`
--

LOCK TABLES `transaction_approval` WRITE;
/*!40000 ALTER TABLE `transaction_approval` DISABLE KEYS */;
INSERT INTO `transaction_approval` VALUES (5000000,30,1,'happy2','PENDING'),(2000000,31,2,'happy2','PENDING'),(1111111,32,3,'happy2','PENDING'),(1111111,33,4,'happy2','APPROVED'),(50000,52,5,'nnnddd','PENDING'),(5000000,53,6,'nnnddd','PENDING'),(5555555,54,7,'nnnddd','PENDING'),(5555555,55,8,'nnnddd','PENDING'),(88888,63,9,'cc88','PENDING');
/*!40000 ALTER TABLE `transaction_approval` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11 11:12:33
