-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a703.p.ssafy.io    Database: pob
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `directory`
--

DROP TABLE IF EXISTS `directory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directory` (
  `institution_code` int NOT NULL,
  `created` datetime(6) NOT NULL,
  `directory_id` bigint NOT NULL AUTO_INCREMENT,
  `updated` datetime(6) NOT NULL,
  `user_key` binary(16) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`directory_id`),
  KEY `FKsouad3hkirwbem2jr85w8wjgi` (`user_key`),
  CONSTRAINT `FKsouad3hkirwbem2jr85w8wjgi` FOREIGN KEY (`user_key`) REFERENCES `user` (`user_key`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directory`
--

LOCK TABLES `directory` WRITE;
/*!40000 ALTER TABLE `directory` DISABLE KEYS */;
INSERT INTO `directory` VALUES (100,'2024-10-10 00:21:52.535692',1,'2024-10-10 00:21:52.535735',_binary '��\�\��@���x=��\�O','Test Directory','123456789','/app/uploads/2e5867d7-fa9f-4ba8-9d22-c62d0696b9a5_IMG_0098 2.JPG'),(100,'2024-10-10 00:22:02.225800',2,'2024-10-10 00:22:02.225828',_binary '��\�\��@���x=��\�O','Test Directory','123456789','/app/uploads/785d7705-c479-4ab7-aac5-dcc93977af8b_IMG_0098 2.JPG'),(100,'2024-10-10 00:22:03.710072',3,'2024-10-10 00:22:03.710096',_binary '��\�\��@���x=��\�O','Test Directory','123456789','/app/uploads/0c5bdb9e-7b98-47c1-b249-7132139c601b_IMG_0098 2.JPG'),(100,'2024-10-10 09:25:39.187264',4,'2024-10-10 09:25:39.187298',_binary '��\�\��@���x=��\�O','park','1223','/app/uploads/f90d4272-f2b3-4038-ae0d-6f0078d1437d_SSA.PNG'),(100,'2024-10-10 10:32:24.776193',5,'2024-10-10 10:32:24.776217',_binary '��Q���JS����\� ��','park','1223','/app/uploads/84abab1c-cea1-4097-81c9-65cef2b57499_SSA.PNG'),(100,'2024-10-10 10:38:52.871738',6,'2024-10-10 10:38:52.871779',_binary '��\�\��@���x=��\�O','counter','8888',''),(100,'2024-10-10 10:39:08.017404',7,'2024-10-10 10:39:08.017442',_binary '��\�\��@���x=��\�O','counter123','8888',''),(1234,'2024-10-10 11:01:34.546827',8,'2024-10-10 11:01:34.546865',_binary '��\�\��@���x=��\�O','jungmin1','123',''),(11,'2024-10-10 11:02:26.183802',9,'2024-10-10 11:02:26.183827',_binary '?�J=%,C\\��ժ\�\�\�','happy1','1111111-00-2222222',''),(1234,'2024-10-10 11:23:06.076077',10,'2024-10-10 11:23:06.076103',_binary '��\�\��@���x=��\�O','jungmin1','123',''),(1,'2024-10-10 16:10:16.518163',11,'2024-10-10 16:10:16.518175',_binary '�m�\"�HI�/Z=Chy','soso1','0015227586415269',''),(11,'2024-10-10 18:35:21.625616',12,'2024-10-10 18:35:21.625626',_binary '�k\�ͭAo�tfN֊�','daddy','0015227586415269',''),(120,'2024-10-10 20:03:38.499916',13,'2024-10-10 20:03:38.499924',_binary '�@�!��G�\��L[�r`','DAD','0016041214042710',''),(345,'2024-10-10 20:04:07.309757',14,'2024-10-10 20:04:07.309766',_binary '�@�!��G�\��L[�r`','grand','0011259539632073',''),(99,'2024-10-11 08:58:48.474417',15,'2024-10-11 08:58:48.474426',_binary 'B���PMI5�E}\�͖','SON','0014077542923679',''),(11,'2024-10-11 09:05:27.987531',16,'2024-10-11 09:05:27.987539',_binary 'B���PMI5�E}\�͖','SONSON','0016075726720575',''),(1,'2024-10-11 09:08:50.527411',17,'2024-10-11 09:08:50.527420',_binary '�=�/Hċ\�\�:\��','gogo','0016439815605491','');
/*!40000 ALTER TABLE `directory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11 11:12:34
