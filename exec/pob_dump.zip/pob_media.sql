-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a703.p.ssafy.io    Database: pob
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `media_id` bigint NOT NULL AUTO_INCREMENT,
  `transaction_unique_no` bigint DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('IMAGE','TEXT','VIDEO','VOICE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,333,'This is a media file','/app/uploads/e466a9dc-1a03-42fb-b62b-ccaa0acb27ac_image (1).png','VIDEO'),(2,333,'This is a media file','/app/uploads/facb5303-fe9e-4de2-b45b-e24ab992d021_image (1).png','VIDEO'),(3,333,'This is a media file','','VIDEO'),(4,333,'','','VIDEO'),(5,333,'','','VIDEO'),(6,33322,'','/app/uploads/b6ec38c7-19f7-4fc2-ba0b-3abb47af24aa_bono.jpg','VIDEO'),(7,333223333,'','','VIDEO'),(8,333223333,'','','VIDEO'),(9,333223333,'','','VIDEO'),(10,333223333,'','','VIDEO'),(11,333223333,'','파일이 제공되지 않았습니다.','VIDEO'),(12,78164,'미디어','파일이 제공되지 않았습니다.','TEXT'),(13,78240,'media media','파일이 제공되지 않았습니다.','TEXT'),(14,333223333,'','파일이 제공되지 않았습니다.','VIDEO'),(15,78260,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(16,333223333,'','/app/uploads/4c42ce0a-3ff5-4f73-b1b8-d4b24cadc0ea_bono.jpg','VIDEO'),(17,333223333,'','/app/uploads/366adf55-a232-4b9a-98fb-acf8190253d4_bono.jpg','IMAGE'),(18,78271,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(19,333223333,'','/app/uploads/3dcdda94-5dfc-4f6b-8216-dfa32abb8eae_bono.jpg','IMAGE'),(20,78278,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(21,333223333,'','파일이 제공되지 않았습니다.','IMAGE'),(22,333223333,'','/app/uploads/08a083d7-9c22-4738-8eb9-f60815d75a9c_bono.jpg','IMAGE'),(23,78306,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(24,78309,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(25,78311,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(26,78341,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(27,333223333,'','파일이 제공되지 않았습니다.','IMAGE'),(28,333223333,'','파일이 제공되지 않았습니다.','IMAGE'),(29,78358,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(30,78366,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(31,78381,'컨텐츠','파일이 제공되지 않았습니다.','IMAGE'),(32,333223333,'','파일이 제공되지 않았습니다.','IMAGE'),(33,333223333,'','파일이 제공되지 않았습니다.','IMAGE'),(34,333223333,'','파일이 제공되지 않았습니다.','IMAGE'),(35,333223333,'','/app/uploads/3def146a-8e8f-4da8-a8a9-d73bdab7416b_서명.png','IMAGE'),(36,333223333,'','/app/uploads/0736799a-8f20-42b6-9d63-7c5a0cd9b9f9_서명.png','IMAGE'),(37,333223333,'','파일이 제공되지 않았습니다.!!!','IMAGE'),(38,78404,'컨텐츠','파일이 제공되지 않았습니다.!!!','IMAGE'),(39,78421,'컨텐츠','파일이 제공되지 않았습니다.!!!','IMAGE'),(40,333223333,'','no file !!!','IMAGE'),(41,333223333,'','/app/uploads/26dcfdee-f9c8-4155-a328-2207060e6e05_bono.jpg','IMAGE'),(42,78431,'컨텐츠','no file !!!','IMAGE'),(43,333223333,'','/app/uploads/513cfde3-9de0-41d9-a43a-95696490fe2a_bono.jpg','IMAGE'),(44,333223333,'','/app/uploads/95badba7-1be6-4ce1-80c6-a81cf4a44187_bono.jpg','IMAGE'),(45,34324,'ㅇㅇㄹㅇㄹ','no file !!!','TEXT'),(46,34324,'ㅇㅇㄹㅇㄹ','no file !!!','VOICE'),(47,333223333,'','/app/uploads/e0082a58-9abb-4fcb-9daf-5a64242374ae_bono.jpg','IMAGE'),(48,78455,'컨텐츠','/app/uploads/cffe9df3-7feb-4bb8-9883-7d00fb7929fb_myImage.jpg','IMAGE'),(49,333223333,'','/app/uploads/203d6552-bf50-4ad5-8166-8cdebfbe7aef_bono.jpg','IMAGE'),(50,333223333,'안여','no file !!!','TEXT'),(51,333223333,'안여','no file !!!','TEXT'),(52,333223333,'안여','no file !!!','TEXT'),(53,79194,'컨텐츠','/app/uploads/a1fb4cb1-ebf1-4f98-9cc7-6f47593a06ca_myImage.jpg','IMAGE'),(54,79250,'컨텐츠','/app/uploads/a699b56b-2af2-4496-ba59-29be85dbbe23_myImage.jpg','IMAGE'),(55,333223333,'안여','no file !!!','TEXT'),(56,311,'안여','no file !!!','TEXT'),(57,79415,'컨텐츠','/app/uploads/7f2d9763-d5be-41fb-af85-9bb44ee1d779_myImage.jpg','IMAGE'),(58,311,'','/app/uploads/01f50695-1200-4e23-a971-55a567f1e999_bono.jpg','IMAGE'),(59,3112,'','/app/uploads/db67c42a-f49b-4a63-8622-703a623eed18_bono.jpg','IMAGE');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11 11:12:34
