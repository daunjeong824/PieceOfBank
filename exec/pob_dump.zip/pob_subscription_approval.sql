-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a703.p.ssafy.io    Database: pob
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subscription_approval`
--

DROP TABLE IF EXISTS `subscription_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_approval` (
  `notification_id` bigint NOT NULL,
  `subscription_approval_id` bigint NOT NULL AUTO_INCREMENT,
  `requester_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('APPROVED','PENDING','REFUSED') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`subscription_approval_id`),
  UNIQUE KEY `UKe2op4xg8ew9sgppmkkdp1mqt1` (`notification_id`),
  CONSTRAINT `FKubcot8py7d0ybju7qg97y2g8` FOREIGN KEY (`notification_id`) REFERENCES `notification` (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_approval`
--

LOCK TABLES `subscription_approval` WRITE;
/*!40000 ALTER TABLE `subscription_approval` DISABLE KEYS */;
INSERT INTO `subscription_approval` VALUES (1,1,'롱기기','PENDING'),(2,2,'롱기기','PENDING'),(3,3,'따따운','PENDING'),(4,4,'iuiuiu','APPROVED'),(5,5,'iuiuiu','PENDING'),(6,6,'따따운','PENDING'),(7,7,'롱기기','PENDING'),(8,8,'dsds','PENDING'),(9,9,'롱기기','PENDING'),(10,10,'asas44','PENDING'),(11,11,'tttt','APPROVED'),(13,12,'elel','APPROVED'),(14,13,'pp2','APPROVED'),(15,14,'soso2','APPROVED'),(16,15,'따따운','APPROVED'),(17,16,'따따운','PENDING'),(18,17,'e11','APPROVED'),(19,18,'따따운','PENDING'),(20,19,'따따운','PENDING'),(21,20,'hi88','APPROVED'),(22,21,'kk1234','APPROVED'),(23,22,'따따운','PENDING'),(24,23,'snsn22','APPROVED'),(25,24,'따따운','PENDING'),(26,25,'do22','APPROVED'),(27,26,'do44','APPROVED'),(28,27,'happy2','APPROVED'),(34,28,'따따운','PENDING'),(38,29,'papa1','APPROVED'),(39,30,'wawa1','APPROVED'),(40,31,'eww','APPROVED'),(41,32,'rewq','APPROVED'),(42,33,'aka','APPROVED'),(43,34,'zzxxx','PENDING'),(44,35,'hoho2','PENDING'),(45,36,'zzxc','APPROVED'),(46,37,'aus','PENDING'),(47,38,'qhqh','APPROVED'),(48,39,'sisi','APPROVED'),(49,40,'test55','APPROVED'),(50,41,'son','APPROVED'),(51,42,'nnnddd','APPROVED'),(56,43,'cc88','PENDING'),(57,44,'cc88','APPROVED'),(58,45,'cc88','PENDING'),(59,46,'wjdek','APPROVED'),(60,47,'wjdek','APPROVED'),(61,48,'wjdek','APPROVED'),(64,49,'eee','APPROVED'),(65,50,'endsk','APPROVED');
/*!40000 ALTER TABLE `subscription_approval` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11 11:12:32
